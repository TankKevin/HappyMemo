//
//  BasicViewController.swift
//  HappyMemorizingChineseEdition
//
//  Created by 谭凯文 on 2017/11/21.
//  Copyright © 2017年 Tan Kevin. All rights reserved.
//

import UIKit

class BasicViewController: UIViewController {
    
    @IBAction func showRuleAlert(_ sender: UIButton) {
        let showRuleAlert = UIAlertController(title: "规则", message: "根据题目，轻点答案。看看您能冲到第几关。", preferredStyle: .alert)
        showRuleAlert.addAction(UIAlertAction(title: "好", style: .default, handler: nil))
        present(showRuleAlert, animated: true, completion: nil)
    }
    
    @IBAction func showShareMenu(_ sender: UIButton) {
        let defaultText = "推荐这款 app，快去 App Store 下载吧~"
        let shareController = UIActivityViewController(activityItems: [defaultText], applicationActivities: nil)
        self.present(shareController, animated: true, completion: nil)
    }

}
