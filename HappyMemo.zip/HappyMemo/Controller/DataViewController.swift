//
//  DataViewController.swift
//  HappyMemorizingChineseEdition
//
//  Created by 谭凯文 on 2017/12/4.
//  Copyright © 2017年 Tan Kevin. All rights reserved.
//

import UIKit

class DataViewController: UITableViewController {
    
    var provinces: [Province] = [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28, zhi1, zhi2, zhi3, zhi4]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Configure the navigation bar appearance
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.tintColor = .black
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    
    // MARK: - Table view data source


    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return provinces.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "KeyNameCell", for: indexPath) as! SimpleLabelCell
        cell.label.text = provinces[indexPath.row].provinceName

        return cell
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showLockTable" {
            let destinationController = segue.destination as! DataLockViewController
            destinationController.provinceGet = provinces[tableView.indexPathForSelectedRow!.row]
            
        }
    }

}
