//
//  DetailViewController.swift
//  HappyMemorizingChineseEdition
//
//  Created by 谭凯文 on 2017/11/26.
//  Copyright © 2017年 Tan Kevin. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    // MARK: - Properties
    var lockCity = ""
    var keyProvince = ""
    var grade = 0
    var max = 0
    var times = 0
    
    @IBOutlet var tableView: UITableView!
    
    // MARK: - View controller life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Configure the navigation bar appearance
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.tintColor = .white
        tableView.contentInsetAdjustmentBehavior = .never
        
        // Configure the table view
        tableView.separatorStyle = .none
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.navigationBar.tintColor = .white
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - UITableViewDataSource methods
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }//not necessary
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }//necessary
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        switch indexPath.row {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "TimesCell", for: indexPath) as! SimpleLabelCell
            cell.label.text = "第 \(times) 次挑战"
            cell.selectionStyle = .none
            
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "GradeCell", for: indexPath) as! SimpleLabelCell
            cell.label.text = "本次连续答对 \(grade) 题"
            cell.selectionStyle = .none
            
            return cell
        case 2:
            let cell = tableView.dequeueReusableCell(withIdentifier: "MaxCell", for: indexPath) as! SimpleLabelCell
            cell.label.text = "历史最多连对 \(max) 题"
            cell.selectionStyle = .none
            
            return cell
        case 3:
            let cell = tableView.dequeueReusableCell(withIdentifier: "AnswerCell", for: indexPath) as! SimpleLabelCell
            cell.label.text = "\(lockCity)位于\(keyProvince)"
            cell.selectionStyle = .none
            
            return cell
        case 4:
            let cell = tableView.dequeueReusableCell(withIdentifier: "SearchCell", for: indexPath) as! ButtonCell
            cell.button.setTitle("点击用百度搜索“\(lockCity)”", for: .normal)
            cell.selectionStyle = .none
            
            return cell
        case 5:
            let cell = tableView.dequeueReusableCell(withIdentifier: "MapHeadCell", for: indexPath) as! ButtonCell
            cell.button.setTitle("点击查看\(lockCity)的地图", for: .normal)
            cell.selectionStyle = .none
            
            return cell
        default:
            fatalError("Failed to instantiate the table view cell for detail view controller")
        }
    }//necessary
    
    
    @IBAction func searchWithBaidu() {
        let link: NSString = "http://www.baidu.com/s?wd=\(lockCity)" as NSString
        let encodedlLink = link.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed)
        if let url = URL(string: encodedlLink!) {
            UIApplication.shared.open(url)
        }
    }
    
    @IBAction func showMap() {
        let link: NSString = "http://maps.apple.com/?address=\(lockCity)" as NSString
        let encodedlLink = link.addingPercentEncoding(withAllowedCharacters: NSCharacterSet.urlQueryAllowed)
        if let url = URL(string: encodedlLink!) {
            UIApplication.shared.open(url)
        }
    }

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    
    
    
    


    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
     
     
     
     let cell = tableView.dequeueReusableCell(withIdentifier: "SearchCell", for: indexPath) as! SearchButtonCell
     cell.searchButton.setTitle("用百度搜索“\(lockCity)”", for: .normal)
     cell.selectionStyle = .none
     
     return cell
    */

}

