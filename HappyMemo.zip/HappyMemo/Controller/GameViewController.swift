//
//  GameViewController.swift
//  HappyMemorizingChineseEdition
//
//  Created by 谭凯文 on 2017/11/21.
//  Copyright © 2017年 Tan Kevin. All rights reserved.
//

import UIKit
import CoreData
import AudioToolbox
import AVFoundation

class GameViewController: UITableViewController {
    
    var provinces = [String]()
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        
    }
    
    // MARK: - Properties
    @IBOutlet var number: UILabel!
    @IBOutlet var question: UILabel!
    
    @IBOutlet var detailButton: UIButton!
    @IBOutlet var refreshButton: UIButton!
    
//    var interfaceDic: [String: String] = {
//        if let dic =
//        return [String: String]()
//    }()
    
    let interfaceURL: URL = {
        let documentURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return documentURL.appendingPathComponent("interface.archive")
    }()
    
    var challenge = Challenge()
    
    // FIXME: Segue
    var segueGrade = 0
    var segueMax = 0
    var segueTimes = 0
    
    // The model of options to store data
//    var options = [String]()
    
    // MARK: - View life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        audioPlay(audioName: "pianoturn")
        
        refreshButton.isHidden = true
        detailButton.isHidden = true
        
        
        
//        if let oldData = getOldData() {
//            challenge.loadFromMemory(choices: oldData)
//        } else {
//            challenge.reset()
//        }
        
        updateView()
    }
    
    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        tableView.rowHeight = 80
        return 4
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StaticCell")!
        
        cell.textLabel?.text = challenge.options[indexPath.row]
        
        return cell
    }
    
    
    
    func updateView() {
//        for index in 0...3 {
//            optionButtons[index].setTitle(challenge.options[index], for: .normal)
//        }
        tableView.reloadData()
        
        question.text = challenge.currentLock
        number.text = "\(challenge.continualBingos + 1)"
//        view.addSubview(question)
//        view.addSubview(number)

        detailButton.isHidden = true
        refreshButton.isHidden = true//隐藏两个按钮
        
        
    }
    
    
    // 函数功能：在界面消失后进行处理。删除data中的所有数据。如果刚才处于过程（非错误）界面，则将界面数据保存到data，否则无动作。
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        
        // If the answer is not wrong. Write the data to the file.
//        NSKeyedArchiver.archiveRootObject(interfaceDic, toFile: interfaceURL.path)
        
        
        
        
//        if let appDelegate = (UIApplication.shared.delegate as? AppDelegate) {
//            var optionsAsArray: [CurrentOptionsMO] = []
//            let request: NSFetchRequest<CurrentOptionsMO> = CurrentOptionsMO.fetchRequest()
//            let context = appDelegate.persistentContainer.viewContext
//            do {
//                optionsAsArray = try context.fetch(request)
//            } catch {
//                print(error)
//            }
//            if optionsAsArray.count != 0 {
//                for i in 1...optionsAsArray.count {
//                    context.delete(optionsAsArray[i - 1])
//                }
//                appDelegate.saveContext()
//            }
//            if !challenge.isWrongNow {
//                let currentOptions = CurrentOptionsMO(context: appDelegate.persistentContainer.viewContext)
//                currentOptions.cityLock = challenge.currentLock
//                currentOptions.number = Int16(challenge.continualBingos)
//                currentOptions.provinceA = challenge.options[0]
//                currentOptions.provinceB = challenge.options[1]
//                currentOptions.provinceC = challenge.options[2]
//                currentOptions.provinceD = challenge.options[3]
//                currentOptions.correctAnswer = challenge.currentKey
//                appDelegate.saveContext()
//            }
//        }
    }
    
//    // MARK: - Action函数
//    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        <#code#>
//    }
    
    @IBAction func tapOneKeyButton(_ sender: UIButton) {
        if sender.currentTitle == challenge.currentKey {
            playSingleMusic()
            challenge.continualBingos += 1
            challenge.appendGoneCities()
            challenge.reset()
            challenge.isWrongNow = false
            updateView()
        } else if sender.currentTitle != "" {
            AudioServicesPlayAlertSound(SystemSoundID(1074))//播放系统声音加震动
            setRecord()//coredata添加纪录
            challenge.continualBingos = 0
            challenge.isWrongNow = true
            sender.backgroundColor = .red//button变红
            //显示两个按钮
            detailButton.isHidden = false
            refreshButton.isHidden = false
            //禁用四个button
//            for keyButton in optionButtons {
//                keyButton.isEnabled = false
//            }
        }
    }
    @IBAction func hasTappedNextButton(_ sender: UIButton) {
        audioPlay(audioName: "pianoturn")//播放转场音乐
        challenge.reset()
        updateView()
        challenge.goneCities = []//免复数据清空
        challenge.isWrongNow = false
    }
    
    // MARK: - 传递数据segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier! == "showDetail" {
            let destinationController = segue.destination as! DetailViewController
            destinationController.lockCity = challenge.currentLock
            destinationController.keyProvince = challenge.currentKey
            destinationController.grade = segueGrade
            destinationController.times = segueTimes
            destinationController.max = segueMax
        } else {
            fatalError("Wrong with segue ...")
        }
    }
    
    
    // MARK: - CoreData
    // 函数作用：
    func setRecord() {
        if let appDelegate = (UIApplication.shared.delegate as? AppDelegate) {
            //提取所有旧的到gameRecords数组：
            var gameRecords: [GameRecordMO] = []
            let request: NSFetchRequest<GameRecordMO> = GameRecordMO.fetchRequest()
            let context = appDelegate.persistentContainer.viewContext
            do {
                gameRecords = try context.fetch(request)
            } catch {
                print(error)
            }
            //添加一个新的record
            let gameRecord = GameRecordMO(context: appDelegate.persistentContainer.viewContext)
            gameRecord.time = Int16(gameRecords.count) + 1
            gameRecord.record = Int16(challenge.continualBingos)
            appDelegate.saveContext()
            segueTimes = gameRecords.count + 1
            var maxRecord = 0
            for i in gameRecords {
                if maxRecord < i.record {
                    maxRecord = Int(i.record)
                }
            }
            segueMax = maxRecord
            segueGrade = challenge.continualBingos
        }
    }
    

    // MARK: - Audio
    
    func audioPlay(audioName: String) {
        var audioPlayer: AVAudioPlayer!
        let url = URL.init(fileURLWithPath: Bundle.main.path(forResource: audioName, ofType: "MP3")!)
        do {
            try audioPlayer = AVAudioPlayer(contentsOf: url)
            audioPlayer.prepareToPlay()
        } catch {
            NSLog("Failed to set audio session category. Error: \(error)")
        }
        audioPlayer.play()
    }
    var keyMusicTitle: [String] = ["C", "#C", "D", "#D", "E", "F", "#F", "G", "#G", "A", "#A", "B"]
    var keyMusicNumber: [String] = ["1", "2", "3", "4", "5", "6", "7"]
    var currentMusicTitleIndex = 0
    var currentMusicNumberIndex = 0
    
    
    func playSingleMusic() {
        let musicToPlay = keyMusicTitle[currentMusicTitleIndex] + keyMusicNumber[currentMusicNumberIndex]
        audioPlay(audioName: musicToPlay)
        currentMusicTitleIndex += 1
        if currentMusicTitleIndex > 11 {
            currentMusicTitleIndex = 0
            currentMusicNumberIndex += 1
        }
        if currentMusicNumberIndex > 11 {
            currentMusicNumberIndex = 0
        }
    }
    
    
}
