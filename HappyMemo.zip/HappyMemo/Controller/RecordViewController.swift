//
//  RecordViewController.swift
//  HappyMemorizingChineseEdition
//
//  Created by 谭凯文 on 2017/11/25.
//  Copyright © 2017年 Tan Kevin. All rights reserved.
//

import CoreData
import UIKit

class RecordViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    lazy var gameRecords: [GameRecordMO] = {
        var records = [GameRecordMO]()
        
        // Fetch the records from core data
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            let request: NSFetchRequest<GameRecordMO> = GameRecordMO.fetchRequest()
            let context = appDelegate.persistentContainer.viewContext
            do {
                records = try context.fetch(request)
            } catch {
                print(error)
            }
        }
        
        return records
    }()

    // MARK: - View life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
//        navigationController?.navigationBar.shadowImage = UIImage()
//        navigationController?.navigationBar.tintColor = .red
        
        
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // FIXME: There's a better way but I forget it...???
        // If the user has never use it before, present an alert.
        let leaveAlert = UIAlertController(title: "第一次来?", message: "请先做题吧", preferredStyle: .alert)
        let leaveAlertAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        leaveAlert.addAction(leaveAlertAction)
    }
    
    // MARK: - UITableViewDataSource methods
    
    // FIXME: Redo this using static cells
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var average = 0.0
        switch indexPath.row {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "TimesCell", for: indexPath) as! SimpleLabelCell
            cell.label.text = "挑战次数 \(gameRecords.count)"
            cell.selectionStyle = .none
            
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "MaxCell", for: indexPath) as! SimpleLabelCell
            var maxRecord = 0
            for i in gameRecords {
                if maxRecord < i.record {
                    maxRecord = Int(i.record)
                }
            }
            cell.label.text = "最大值 \(maxRecord)"
            cell.selectionStyle = .none
            
            return cell
        case 2:
            let cell = tableView.dequeueReusableCell(withIdentifier: "AverageCell", for: indexPath) as! SimpleLabelCell
            var sum: Int16 = 0
            for i in gameRecords {
                sum += i.record
            }
            if gameRecords.count != 0 {
                average = Double(sum) / Double(gameRecords.count)
            }
            cell.label.text = "均值 \(average)"
            cell.selectionStyle = .none
            
            return cell
        case 3:
            let cell = tableView.dequeueReusableCell(withIdentifier: "VarianceCell", for: indexPath) as! SimpleLabelCell
            var square = 0.0
            if gameRecords.count != 0 {
                var sumsquare = 0.0
                for i in gameRecords {
                    sumsquare += (average - Double(i.record)) * (average - Double(i.record))
                }
                square = sumsquare / Double(gameRecords.count)
            }
            cell.label.text = "方差 \(square)"
            cell.selectionStyle = .none
            
            return cell
        default:
            fatalError("Failed to instantiate the table view cell in RecordViewController")
        }
    }
    

}
