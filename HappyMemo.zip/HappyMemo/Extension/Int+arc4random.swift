//
//  IntRandom.swift
//  HappyMemorizingChineseEdition
//
//  Created by 谭凯文 on 2017/12/16.
//  Copyright © 2017年 Tan Kevin. All rights reserved.
//

import Foundation

extension Int {
    var arc4random: Int {
        if self > 0 {
            return Int(arc4random_uniform(UInt32(self)))
        } else if self < 0 {
            return -Int(arc4random_uniform(UInt32(-self)))
        } else {
            return 0
        }
    }
}
