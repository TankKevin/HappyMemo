//
//  Challenge.swift
//  HappyMemorizingChineseEdition
//
//  Created by 谭凯文 on 2017/12/16.
//  Copyright © 2017年 Tan Kevin. All rights reserved.
//
import Foundation

class Challenge {
    var provinces: [Province] = [zhi1, zhi2, zhi3, zhi4, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18, p19, p20, p21, p22, p23, p24, p25, p26, p27, p28]
    var currentKey = ""
    var currentLock = ""
    var continualBingos = 0
    var goneCities = [String]()
    var isWrongNow = false
    var options = [String]()
    func appendGoneCities() {
        goneCities.append(currentLock)
    }
//    func loadFromMemory(choices: CurrentOptionsMO) {
//        options.append(choices.provinceA!)
//        options.append(choices.provinceB!)
//        options.append(choices.provinceC!)
//        options.append(choices.provinceD!)
//        currentLock = choices.cityLock!
//        currentKey = choices.correctAnswer!
//        continualBingos = Int(choices.number)
//    }
    func reset() {
        repeat {
            let i = 32.arc4random
            currentLock = provinces[i].randomChooseACity()
            currentKey = provinces[i].provinceName
        } while goneCities.contains(currentLock)//如果city被用过，重复
        let municipality = ["北京市", "上海市", "天津市", "重庆市"]
        if municipality.contains(currentKey) {
            options = municipality
        } else {
            options = ["", "", "", ""]
            setNotMunicipality()
        }
    }
    func setNotMunicipality() {
        for index in 0...3 {
            options[index] = provinces[28.arc4random + 4].provinceName
        }
        options[4.arc4random] = currentKey
        var newOptions = options
        while newOptions.count > 0 {
            let byOption = newOptions.remove(at: 0)
            if newOptions.contains(byOption) {
                setNotMunicipality()//递归调用：避免出现同一道题有几个相同选项
            }
        }
    }
}
