//
//  ProvinceData.swift
//  HappyMemorizingChineseEdition
//
//  Created by 谭凯文 on 2017/11/21.
//  Copyright © 2017年 Tan Kevin. All rights reserved.
//

var zhi1 = Province(provinceName: "北京市", cityName: "东城区,西城区,朝阳区,丰台区,石景山区,海淀区,顺义区,通州区,大兴区,房山区,门头沟区,昌平区,平谷区,密云区,怀柔区,延庆区")
var zhi2 = Province(provinceName: "上海市", cityName: "黄浦区,徐汇区,长宁区,静安区,普陀区,闸北区,虹口区,杨浦区,金山区,奉贤区,闵行区,松江区,宝山区,青浦区,嘉定区,崇明区,浦东新区")
var zhi3 = Province(provinceName: "天津市", cityName: "和平区,河西区,河北区,河东区,南开区,红桥区,北辰区,西青区,大港区,塘沽区,汉沽区,宝坻区,蓟县,东丽区,武清区,静海县,宁河县,静海县")
var zhi4 = Province(provinceName: "重庆市", cityName: "万州区,黔江区,涪陵区,渝中区,大渡口区,江北区,沙坪坝区,九龙坡区,南岸区,北碚区,渝北区,巴南区,长寿区,江津区,合川区,永川区,南川区,綦江区,大足区,璧山区,铜梁区,潼南区,荣昌区,开州区,梁平区,武隆区,城口县,丰都县,垫江县,忠县,云阳县,奉节县,巫山县,巫溪县,石柱土家族自治县,秀山土家族苗族自治县,酉阳土家族苗族自治县,彭水苗族土家族自治县")
var p1 = Province(provinceName: "河北省", cityName: "石家庄市,唐山市,秦皇岛市,邯郸市,邢台市,保定市,张家口市,承德市,沧州市,廊坊市,衡水市")
var p2 = Province(provinceName: "山西省", cityName: "太原市,大同市,朔州市,忻州市,阳泉市,吕梁市,晋中市,长治市,晋城市,临汾市,运城市")
var p3 = Province(provinceName: "内蒙古自治区", cityName: "呼和浩特市,包头市,乌海市,赤峰市,通辽市,鄂尔多斯市,呼伦贝尔市,乌兰察布市,巴彦淖尔市,兴安盟,阿拉善盟,锡林郭勒盟")//?
var p4 = Province(provinceName: "黑龙江省", cityName: "哈尔滨市,齐齐哈尔市,鸡西市,鹤岗市,双鸭山市,大庆市,伊春市,佳木斯市,七台河市,牡丹江市,黑河市,绥化市,大兴安岭地区")
var p5 = Province(provinceName: "吉林省", cityName: "长春市,吉林市,四平市,通化市,长白山市,辽源市,白城市,松原市,延边朝鲜族自治州")
var p6 = Province(provinceName: "辽宁省", cityName: "沈阳市,大连市,朝阳市,阜新市,铁岭市,抚顺市,本溪市,辽阳市,鞍山市,丹东市,营口市,盘锦市,锦州市,葫芦岛市")
var p7 = Province(provinceName: "陕西省", cityName: "西安市,咸阳市,宝鸡市,渭南市,铜川市,延安市,榆林市,汉中市,安康市,商洛市")
var p8 = Province(provinceName: "甘肃省", cityName: "兰州市,天水市,白银市,平凉市,庆阳市,陇南市,定西市,金昌市,武威市,张掖市,酒泉市,嘉峪关市,临夏回族自治州,甘南藏族自治州")
var p9 = Province(provinceName: "青海省", cityName: "西宁市,海东市,海北藏族自治州,黄南藏族自治州,海南藏族自治州,果洛藏族自治州,玉树藏族自治州,海西蒙古族藏族自治州")//?
var p10 = Province(provinceName: "云南省", cityName: "昆明市,曲靖市,玉溪市,昭通市,保山市,丽江市,普洱市,临沧市,德宏傣族景颇族自治州,怒江傈僳族自治州,大理白族自治州,大理市,楚雄市,红河哈尼族彝族自治州,文山壮族苗族自治州,西双版纳傣族自治州")//?
var p11 = Province(provinceName: "新疆维吾尔自治区", cityName: "乌鲁木齐市,克拉玛依市,吐鲁番市,哈密市,阿勒泰地区,阿克苏地区,喀什地区,和田地区,昌吉回族自治州,博尔塔拉蒙古自治州,巴音郭楞蒙古自治州,克孜勒苏柯尔克孜自治州,伊犁哈萨克自治州")
var p12 = Province(provinceName: "宁夏回族自治区", cityName: "银川市,石嘴山市,吴忠市,固原市,中卫市")
var p13 = Province(provinceName: "山东省", cityName: "济南市,泰安市,潍坊市,德州市,滨州市,莱芜市,青岛市,烟台市,日照市,东营市,济宁市,荷泽市,聊城市,临沂市,枣庄市,淄博市,威海市")
var p14 = Province(provinceName: "河南省", cityName: "郑州市,洛阳市,开封市,南阳市,安阳市,商丘市,新乡市,平顶山市,许昌市,焦作市,周口市,信阳市,驻马店市,鹤壁市,濮阳市,漯河市,三门峡市,济源市")
var p15 = Province(provinceName: "江苏省", cityName: "南京市,无锡市,徐州市,常州市,苏州市,南通市,连云港市,淮安市,盐城市,扬州市,镇江市,泰州市,宿迁市")
var p16 = Province(provinceName: "浙江省", cityName: "杭州市,宁波市,温州市,嘉兴市,湖州市,绍兴市,金华市,衢州市,舟山市,台州市,丽水市")
var p17 = Province(provinceName: "安徽省", cityName: "合肥市,淮北市,亳州市,宿州市,阜阳市,蚌埠市,淮南市,滁州市,六安市,芜湖市,马鞍山市,铜陵市,安庆市,池州市,宣城市,黄山市")
var p18 = Province(provinceName: "江西省", cityName: "南昌市,九江市,赣州市,吉安市,萍乡市,鹰潭市,新余市,宜春市,上饶市,景德镇市,抚州市")
var p19 = Province(provinceName: "福建省", cityName: "福州市,厦门市,泉州市,三明市,南平市,龙岩市,漳州市,宁德市,莆田市")
var p20 = Province(provinceName: "台湾省", cityName: "台北市,高雄市")
var p21 = Province(provinceName: "湖北省", cityName: "武汉市,黄石市,十堰市,荆州市,宜昌市,襄阳市,鄂州市,荆门市,孝感市,黄冈市,咸宁市,随州市,恩施土家族苗族自治州,仙桃市,天门市,潜江市,神农架林区")
var p22 = Province(provinceName: "湖南省", cityName: "长沙市,岳阳市,常德市,株洲市,湘潭市,衡阳市,益阳市,张家界市,郴州市,娄底市,邵阳市,永州市,怀化市,湘西土家族自治州")
var p23 = Province(provinceName: "广东省", cityName: "广州市,深圳市,珠海市,东莞市,佛山市,中山市,惠州市,汕头市,江门市,茂名市,肇庆市,湛江市,梅州市,汕尾市,河源市,清远市,韶关市,揭阳市,阳江市,潮州市,云浮市")
var p24 = Province(provinceName: "广西壮族自治区", cityName: "南宁市,桂林市,柳州市,梧州市,钦州市,北海市,玉林市,贵港市,防城港市,百色市,崇左市,来宾市,贺州市,河池市")
var p25 = Province(provinceName: "海南省", cityName: "海口市,三亚市,三沙市,儋州市")
var p26 = Province(provinceName: "四川省", cityName: "成都市,自贡市,攀枝花市,泸州市,德阳市,绵阳市,广元市,遂宁市,内江市,乐山市,南充市,宜宾市,广安市,达州市,巴中市,雅安市,眉山市,资阳市,阿坝藏族羌族自治州,甘孜藏族自治州,凉山彝族自治州")
var p27 = Province(provinceName: "贵州省", cityName: "贵阳市,遵义市,六盘水市,安顺市,毕节地区,铜仁地区,黔西南布依族苗族自治州,黔东南苗族侗族自治州,黔南布依族苗族自治州")
var p28 = Province(provinceName: "西藏自治区", cityName: "拉萨市,日喀则市,昌都市,林芝市,山南市,那曲地区,阿里地区")
