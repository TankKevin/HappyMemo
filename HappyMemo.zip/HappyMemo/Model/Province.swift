//
//  ProvinceStructDefinition.swift
//  HappyMemorizingChineseEdition
//
//  Created by 谭凯文 on 2017/11/21.
//  Copyright © 2017年 Tan Kevin. All rights reserved.
//

import Foundation

struct Province {
    var provinceName = ""
    var cityNameStringArray = [String]()
    var cityNumber: Int {
        return cityNameStringArray.count
    }
    
    // 函数在该省中生成一个随机的城市名,并用字符串储存返回
    func randomChooseACity() -> String {
        return cityNameStringArray[cityNameStringArray.count.arc4random]
    }
    
    init(provinceName: String, cityName: String) {
        self.provinceName = provinceName
        
        var result = [String]()
        var process = ""
        for i in cityName.indices {
            if ",， 。".contains(cityName[i]) {
                if process != "" {
                    result.append(process)
                    process = ""
                }
            } else {
                process.append(cityName[i])
            }
        }
        if process != "" {
            result.append(process)
            process = ""
        }
        cityNameStringArray = result
    }
    
    init() {}
}


