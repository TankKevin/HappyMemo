//
//  ProvinceSource.swift
//  CityMemorizingPro
//
//  Created by 谭凯文 on 2017/11/16.
//  Copyright © 2017年 Tan Kevin. All rights reserved.
//

import Foundation


//对外开放的：provinceName, cityNumber, ramdomChooseACity
struct Province {
    var provinceName = ""
    var cityName = ""
    
    //生成一个字符数组,储存城市名和逗号
    var cityNameChar: [Character] {
        var tempChar = [Character]()
        for i in cityName {
            tempChar.append(i)
        }
        return tempChar
    }
    
    //用整型储存城市个数
    var cityNumber: Int {
        var num = 0
        for i in cityName {
            if i == "," {
                num += 1
            }
        }
        return num + 1
    }
    
    //函数在该省中生成一个随机的城市名,并用字符串储存返回
    func randomChooseACity() -> String {
        var selectedCity = ""
        let goal = Int(arc4random_uniform(UInt32(cityNumber)))//0-cityNumber-1的随机数
        var num = 0
        var j = 0
        for i in 0...(cityNameChar.count - 1) {
            if num == goal {
                j = i
                while (j<=(cityNameChar.count-1))&&(cityNameChar[j] != ",") {
                    selectedCity.append(cityNameChar[j])
                    j += 1
                }
                break
            } else if cityNameChar[i] == "," {
                num += 1
            }
        }
        return selectedCity
    }
}


