//
//  SimpleLabelCell.swift
//  HappyMemorizingChineseEdition
//
//  Created by 谭凯文 on 2017/12/1.
//  Copyright © 2017年 Tan Kevin. All rights reserved.
//

import UIKit

class SimpleLabelCell: UITableViewCell {
    
    @IBOutlet var label: UILabel! {
        didSet {
            label.numberOfLines = 0
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
